function [vysledek] = f(x)
    vysledek = sin(x) + 3*cos(3*x) - 2*sin(x/2) -cos(4*x);
end

